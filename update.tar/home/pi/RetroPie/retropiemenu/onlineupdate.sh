cd /home/pi/
git clone --depth=1 https://gitee.com/ln93/NP-RPI4-UPD.git
cd /
sudo tar -xf /home/pi/NP-RPI4-UPD/update.tar 
cd /home/pi/NP-RPI4-UPD/
sudo chmod +x update.sh
sudo ./update.sh
cd /
rm -rf /home/pi/NP-RPI4-UPD/
sync
sudo reboot now
