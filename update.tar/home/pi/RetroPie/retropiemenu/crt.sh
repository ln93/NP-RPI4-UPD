cp -r /home/pi/NP-CRT/* /opt/retropie/configs/all/retroarch/config/
