rm -rf /opt/retropie/configs/all/retroarch/config/*
